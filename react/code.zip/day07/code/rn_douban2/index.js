import { AppRegistry } from 'react-native';
// import App from './App';
import Main from './Main.js'

AppRegistry.registerComponent('rn_douban2', () => Main);
