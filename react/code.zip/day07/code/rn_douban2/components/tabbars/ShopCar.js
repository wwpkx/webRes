import React, { Component } from 'react'
import { View, Text } from 'react-native'

export default class ShopCar extends Component {
  render() {
    return <View>
      <Text>这是 ShopCar 组件</Text>
    </View>
  }
}