// 导入一个 样式的对象
export default {
  boxStyle: { border: '1px solid #ccc', margin: '10px 0', paddingLeft: 15 },
  titleStyle: { fontSize: 16, color: "purple" },
  bodyStyle: { fontSize: 14, color: "red" }
}